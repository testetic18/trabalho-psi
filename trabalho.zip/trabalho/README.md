
---

# Sistema de Gestão de Alunos

Este projeto é um sistema simples para gerir informações sobre alunos, utilizando uma base de dados SQLite. O sistema permite adicionar, visualizar e apagar alunos através de uma base de dados local.

## Funcionalidades

O sistema permite as seguintes funcionalidades:

1. **Adicionar Aluno**: Criação de novos alunos na base de dados.
2. **Mostrar Alunos**: Exibição de todos os alunos presentes na base de dados.
3. **Apagar Aluno**: Apagar um aluno da base de dados através do seu ID.

## Tecnologias Utilizadas

- **Python**: Linguagem de programação principal.
- **SQLite**: Sistema de gestão de base de dados utilizado para armazenar as informações dos alunos.


## Como Usar

### 1. **Adicionar Alunos**
O código `main.py` irá automaticamente adicionar três alunos à base de dados (`Alice`, `Bob`, e `Charlie`) quando for executado. Estes alunos são inseridos na tabela `aluno` da base de dados `DaB.db`.

### 2. **Mostrar Alunos**
Após adicionar os alunos, o sistema irá listar todos os alunos na base de dados. Esta operação é feita através do script `read_alunos.py`.

### 3. **Apagar Aluno**
Para apagar um aluno, basta alterar o valor de `student_id` no código `main.py` para o ID do aluno a ser removido. O código irá buscar o aluno pelo ID e, se encontrado, apagá-lo da base de dados.

### 4. **Executar o Código**
Para executar o sistema, basta rodar o arquivo `main.py`. Ele irá executar as operações de criar alunos, mostrar os alunos e apagar um aluno, na ordem em que estão descritas.

```bash
python main.py
```

## Código

### `main.py`

Este é o script principal que executa todas as operações do sistema.

```python
# ================================
# CRIAÇÃO DE ALUNO (Adicionar alunos)
# ================================

import sqlite3

# Conectar à base de dados (o ficheiro será criado se não existir)
conexao = sqlite3.connect('DaB.db')

# Criar a tabela se ela não existir
cursor = conexao.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS aluno (
    id_aluno INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER NOT NULL
)
''')

# Inserir dados de exemplo na tabela
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Alice', 20)")
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Bob', 22)")
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Charlie', 19)")

# Confirmar as alterações e fechar a conexão
conexao.commit()
conexao.close()

# ================================
# LEITURA DE ALUNO (Mostrar alunos)
# ================================

# Conectar novamente à base de dados e buscar os dados de todos os alunos
conexao = sqlite3.connect("DaB.db")
cursor = conexao.cursor()

# Selecionar todos os alunos da tabela 'aluno'
cursor.execute('SELECT * FROM aluno')
resultados = cursor.fetchall()

# Mostrar cada registo na consola
for registro in resultados:
    print(registro)

# Fechar a conexão
conexao.close()

# ================================
# APAGAR ALUNO (Apagar um aluno)
# ================================

# Definir o ID do aluno a apagar (pode ser alterado para outro ID)
student_id = '1'  # Por exemplo, estamos a apagar o aluno com ID 1

# Conectar à base de dados
conexao = sqlite3.connect('DaB.db')
cursor = conexao.cursor()

# Verificar se o aluno existe na base de dados
cursor.execute("SELECT id_aluno FROM aluno WHERE id_aluno = ?", (student_id,))
student = cursor.fetchone()

# Se o aluno existir, apagá-lo da tabela
if student:
    cursor.execute("DELETE FROM aluno WHERE id_aluno = ?", (student_id,))
    conexao.commit()
    print(f"Aluno com ID '{student_id}' foi apagado.")
else:
    print(f"Aluno com ID '{student_id}' não foi encontrado.")

# Fechar a conexão
conexao.close()
```

### `create_aluno.py`

Este script é responsável por criar a tabela de alunos e adicionar dados iniciais.

```python
import sqlite3

# Conectar à base de dados
conexao = sqlite3.connect('DaB.db')

# "cursor" serve para escrever comandos de sql
cursor = conexao.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS aluno (
    id_aluno INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER NOT NULL
)
''')

# Inserir dados de exemplo
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Alice', 20)")
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Bob', 22)")
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Charlie', 19)")

# Confirmar alterações e fechar a conexão
conexao.commit()
conexao.close()
```

### `read_aluno.py`

Este script permite visualizar todos os alunos presentes na base de dados.

```python
import sqlite3

# Conectar à base de dados
conexao = sqlite3.connect("DaB.db")
cursor = conexao.cursor()

# Selecionar todos os dados da tabela 'aluno'
cursor.execute('SELECT * FROM aluno')
resultados = cursor.fetchall()

# Iterar sobre os resultados e imprimir cada registo
for registro in resultados:
    print(registro)

# Fechar a conexão
conexao.close()
```

### `delete_aluno.py`

Este script permite apagar um aluno da base de dados com base no seu ID.

```python
import sqlite3

# Pedir o ID do aluno a apagar
student_id = input("Enter the id of the student to delete: ")

# Conectar à base de dados
conexao = sqlite3.connect('DaB.db')
cursor = conexao.cursor()

# Procurar o aluno pelo ID
cursor.execute("SELECT id_aluno FROM aluno WHERE id_aluno = ?", (student_id,))
student = cursor.fetchone()

# Se o aluno for encontrado, apagar
if student:
    cursor.execute("DELETE FROM aluno WHERE id_aluno = ?", (student_id,))
    conexao.commit()
    print(f"Aluno com o ID '{student_id}' foi apagado.")
else:
    print(f"Aluno com o ID '{student_id}' não foi encontrado.")

# Fechar a conexão
conexao.close()
```

## Conclusão

Este sistema simples permite a gestão de alunos utilizando a base de dados SQLite. Pode ser facilmente expandido para incluir outras funcionalidades, como atualizar informações de alunos, ou adicionar novos tipos de dados à tabela.

---