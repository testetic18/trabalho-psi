# ================================
# CRIAÇÃO DE ALUNO (Adicionar alunos)
# ================================

import sqlite3

# Conectar à base de dados (o ficheiro será criado se não existir)
conexao = sqlite3.connect('DaB.db')

# Criar a tabela se ela não existir
cursor = conexao.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS aluno (
    id_aluno INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER NOT NULL
)
''')

# Inserir dados de exemplo na tabela
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Alice', 20)")
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Bob', 22)")
cursor.execute("INSERT INTO aluno (nome, idade) VALUES ('Charlie', 19)")

# Confirmar as alterações e fechar a conexão
conexao.commit()
conexao.close()

# ================================
# LEITURA DE ALUNO (Mostrar alunos)
# ================================

# Conectar novamente à base de dados e buscar os dados de todos os alunos
conexao = sqlite3.connect("DaB.db")
cursor = conexao.cursor()

# Selecionar todos os alunos da tabela 'aluno'
cursor.execute('SELECT * FROM aluno')
resultados = cursor.fetchall()

# Mostrar cada registo na consola
for registro in resultados:
    print(registro)

# Fechar a conexão
conexao.close()

# ================================
# APAGAR ALUNO (Apagar um aluno)
# ================================

# Definir o ID do aluno a apagar (pode ser alterado para outro ID)
student_id = '1'  # Por exemplo, estamos a apagar o aluno com ID 1

# Conectar à base de dados
conexao = sqlite3.connect('DaB.db')
cursor = conexao.cursor()

# Verificar se o aluno existe na base de dados
cursor.execute("SELECT id_aluno FROM aluno WHERE id_aluno = ?", (student_id,))
student = cursor.fetchone()

# Se o aluno existir, apagá-lo da tabela
if student:
    cursor.execute("DELETE FROM aluno WHERE id_aluno = ?", (student_id,))
    conexao.commit()
    print(f"Aluno com ID '{student_id}' foi apagado.")
else:
    print(f"Aluno com ID '{student_id}' não foi encontrado.")

# Fechar a conexão
conexao.close()
