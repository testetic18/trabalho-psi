import sqlite3

# Conectar ao banco de dados
conexao = sqlite3.connect("DaB.db")
cursor = conexao.cursor()

# Selecionar todos os dados da tabela 'alunos'
cursor.execute('SELECT * FROM alunos')
resultados = cursor.fetchall()

# Iterar sobre os resultados e imprimir cada registro
for registro in resultados:
    print(registro)

# Fechar a conexão
conexao.close()
